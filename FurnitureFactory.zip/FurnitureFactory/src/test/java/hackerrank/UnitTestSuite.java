package hackerrank;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
   SampleUnitTest.class,
   PrivateUnitTest.class
})

public class UnitTestSuite {

}
